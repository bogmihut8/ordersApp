@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div style="margin-bottom:20px;">
                <a class="btn btn-default" href="{{ url()->previous() }}">
                    <i class="fa fa-chevron-left"></i> Inapoi
                </a>
            </div>
            <div class="panel panel-default">
                <div class="panel-heading">Creare comanda noua</div>
                <div class="panel-body">
                    <form class="form-horizontal" role="form" method="POST" action="{{ url('/order') }}">
                        {{ csrf_field() }}

                        <div class="form-group">
                            <label for="name" class="col-md-4 control-label">Nume</label>

                            <div class="col-md-6{{ $errors->has('name') ? ' has-error' : '' }}">
                                <input id="name" type="text" class="form-control" name="name" value="{{ old('name') }}">
                                @if ($errors->has('name'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('name') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="article" class="col-md-4 control-label">Articol</label>

                            <div class="col-md-6{{ $errors->has('article') ? ' has-error' : '' }}">
                                <input id="article" type="text" class="form-control" name="article" value="{{ old('article') }}">
                                @if ($errors->has('article'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('article') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="quantity" class="col-md-4 control-label">Cantitate</label>

                            <div class="col-md-6{{ $errors->has('quantity') ? ' has-error' : '' }}">
                                <input id="quantity" type="number" class="form-control" name="quantity" value="{{ old('quantity') }}">
                                @if ($errors->has('quantity'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('quantity') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="client_id" class="col-md-4 control-label">Client</label>

                            <div class="col-md-6">
                                <select name="client_id" class="form-control">
                                    @foreach($clients as $client)
                                        <option value="{{ $client['id'] }}">{{ $client['name'] }}</option>
                                    @endforeach  
                                </select>
                            </div>
                        </div>
                        
                        <!--<div class="form-group">-->
                        <!--    <label for="parcels" class="col-md-4 control-label">Colete</label>-->

                        <!--    <div class="col-md-6">-->
                        <!--        <input id="parcels" type="number" class="form-control" name="parcels">-->
                        <!--    </div>-->
                        <!--</div>-->
                        
                        <!--<div class="form-group">-->
                        <!--    <label for="weight" class="col-md-4 control-label">Greutate</label>-->

                        <!--    <div class="col-md-6">-->
                        <!--        <input id="weight" type="number" class="form-control" name="weight">-->
                        <!--    </div>-->
                        <!--</div>-->
                        
                        <div class="form-group">
                            <label for="due_date" class="col-md-4 control-label">Data finalizare</label>

                            <div class="col-md-6{{ $errors->has('due_date') ? ' has-error' : '' }}">
                                <input id="due_date" type="date" class="form-control" name="due_date" value="{{ old('due_date') }}">
                                @if ($errors->has('due_date'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('due_date') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group" style="margin-top:20px;">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fa fa-btn fa-th-list"></i> Creare
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
