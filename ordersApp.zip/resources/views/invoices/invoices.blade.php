@extends('layouts.app')

@section('content')
<div>hue hue</div>
@endsection