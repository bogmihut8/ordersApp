<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <?php if(\Session::has('success')): ?>
              <div class="alert alert-success">
                <p><?php echo e(\Session::get('success')); ?></p>
              </div><br />
            <?php endif; ?>
            <div style="margin-bottom:20px;">
                <h2>Clienti</h2>
                <a class="btn btn-primary" href="<?php echo e(url('/client/create')); ?>">
                    <i class="fa fa-btn fa-users"></i> Creare client nou
                </a>
            </div>
            <table class="table table-striped">
                <thead>
                  <tr>
                    <th>Nume</th>
                    <th>Cod Fiscal</th>
                    <th>Adresa</th>
                    <th>Telefon</th>
                    <th colspan="2">Actiuni</th>
                  </tr>
                </thead>
                <tbody>
                  
                  <?php foreach($clients as $client): ?>
                  <tr>
                    <td><?php echo e($client['name']); ?></td>
                    <td><?php echo e($client['cod_fiscal']); ?></td>
                    <td style="max-width:200px;"><?php echo e($client['adresa']); ?></td>
                    <td><?php echo e($client['telefon']); ?></td>
                    
                    <td>
                        <a href="<?php echo e(action('ClientController@edit', $client['id'])); ?>" class="btn btn-warning">Modificare</a>
                        <form action="<?php echo e(action('ClientController@destroy', $client['id'])); ?>" method="post" style="display:inline;margin-left:10px;">
                            <?php echo e(csrf_field()); ?>

                            <input name="_method" type="hidden" value="DELETE">
                            <button class="btn btn-danger" type="submit">Stergere</button>
                      </form>
                      <a href="<?php echo e(action('OrderController@clientOrders', $client['id'])); ?>" class="btn btn-primary" style="margin-left:10px;">Facturi</a>
                    </td>
                  </tr>
                  <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>