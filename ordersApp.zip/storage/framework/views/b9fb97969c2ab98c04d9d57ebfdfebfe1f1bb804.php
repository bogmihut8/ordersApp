<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div style="margin-bottom:20px;">
                <a class="btn btn-default" href="<?php echo e(url()->previous()); ?>">
                    <i class="fa fa-chevron-left"></i> Inapoi
                </a>
            </div>
            <?php if(\Session::has('success')): ?>
                <div class="alert alert-success">
                    <p><?php echo e(\Session::get('success')); ?></p>
                </div><br />
            <?php endif; ?>
            <div class="panel panel-default">
                <div class="panel-heading">Vizualizare comanda</div>
                <div class="panel-body" id="order">
                    <form class="form-horizontal" role="form" method="POST" action="<?php echo e(action('OrderController@update', $id)); ?>">
                        <?php echo e(csrf_field()); ?>

                        <div class="row">
                            <div class="col-md-8 col-md-offset-2 input-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                                <span class="input-group-addon" id="name-addon"><b>Nume</b></span>
                                <input type="text" class="form-control" aria-describedby="name-addon" value="<?php echo e($order['name']); ?>" name="name" style="background-color:white">
                            </div>
                            <?php if($errors->has('name')): ?>
                                    <span class="col-md-8 col-md-offset-2 input-group help-block" style="color: #a94442">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                            <?php endif; ?>
                        </div>
                        <div class="row">
                            <div class="col-md-8 col-md-offset-2 input-group<?php echo e($errors->has('article') ? ' has-error' : ''); ?>">
                                <span class="input-group-addon" id="article-addon"><b>Articol</b></span>
                                <input type="text" class="form-control" aria-describedby="article-addon" value="<?php echo e($order['article']); ?>" name="article" style="background-color:white">
                            </div>
                            <?php if($errors->has('article')): ?>
                                    <span class="col-md-8 col-md-offset-2 input-group help-block" style="color: #a94442">
                                        <strong><?php echo e($errors->first('article')); ?></strong>
                                    </span>
                            <?php endif; ?>
                        </div>
                        <div class="row">
                            <div class="col-md-8 col-md-offset-2 input-group<?php echo e($errors->has('quantity') ? ' has-error' : ''); ?>">
                                <span class="input-group-addon" id="quantity-addon"><b>Cant. totala</b></span>
                                <input type="text" class="form-control" aria-describedby="quantity-addon" value="<?php echo e($order['quantity']); ?>" name="quantity" style="background-color:white">
                            </div>
                            <?php if($errors->has('quantity')): ?>
                                    <span class="col-md-8 col-md-offset-2 input-group help-block" style="color: #a94442">
                                        <strong><?php echo e($errors->first('quantity')); ?></strong>
                                    </span>
                            <?php endif; ?>
                        </div>
                        <div class="row">
                            <div class="col-md-8 col-md-offset-2 input-group<?php echo e($errors->has('delivered') ? ' has-error' : ''); ?>">
                                <span class="input-group-addon" id="delivered-addon"><b>Livrate</b></span>
                                <input type="text" class="form-control" aria-describedby="delivered-addon" value="<?php echo e($order['delivered']); ?>" name="delivered" style="background-color:white">
                                <?php if($errors->has('delivered')): ?>
                                    <span class="col-md-8 col-md-offset-2 input-group help-block" style="color: #a94442">
                                        <strong><?php echo e($errors->first('delivered')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-8 col-md-offset-2 input-group<?php echo e($errors->has('invoiced_products') ? ' has-error' : ''); ?>">
                                <span class="input-group-addon" id="invoiced_products-addon"><b>Facturate</b></span>
                                <input type="text" class="form-control" aria-describedby="invoiced_products-addon" value="<?php echo e($order['invoiced_products']); ?>" name="invoiced_products" style="background-color:white">
                            </div>
                            <?php if($errors->has('invoiced_products')): ?>
                                    <span class="col-md-8 col-md-offset-2 input-group help-block" style="color: #a94442">
                                        <strong><?php echo e($errors->first('invoiced_products')); ?></strong>
                                    </span>
                            <?php endif; ?>
                        </div>
                        <div class="row">
                            <div class="col-md-8 col-md-offset-2 input-group<?php echo e($errors->has('parcels') ? ' has-error' : ''); ?>">
                                <span class="input-group-addon" id="parcels-addon"><b>Numar colete</b></span>
                                <input type="text" class="form-control" aria-describedby="parcels-addon" value="<?php echo e($order['parcels']); ?>" name="parcels" style="background-color:white">
                            </div>
                            <?php if($errors->has('parcels')): ?>
                                    <span class="col-md-8 col-md-offset-2 input-group help-block" style="color: #a94442">
                                        <strong><?php echo e($errors->first('parcels')); ?></strong>
                                    </span>
                            <?php endif; ?>
                        </div>
                        <div class="row">
                            <div class="col-md-8 col-md-offset-2 input-group<?php echo e($errors->has('weight') ? ' has-error' : ''); ?>">
                                <span class="input-group-addon" id="weight-addon"><b>Greutate</b></span>
                                <input type="text" class="form-control" aria-describedby="weight-addon" value="<?php echo e($order['weight']); ?>" name="weight" style="background-color:white">
                            </div>
                            <?php if($errors->has('weight')): ?>
                                    <span class="col-md-8 col-md-offset-2 input-group help-block" style="color: #a94442">
                                        <strong><?php echo e($errors->first('weight')); ?></strong>
                                    </span>
                            <?php endif; ?>
                        </div>
                        <div class="row">
                            <div class="col-md-8 col-md-offset-2 input-group">
                                <span class="input-group-addon" id="client-addon"><b>Client</b></span>
                                <select name="client_id" class="form-control" value="<?php echo e($order->client['id']); ?>" style="padding-left: 10px;">
                                    <?php foreach($clients as $client): ?>
                                        <option value="<?php echo e($client['id']); ?>" <?php echo e(( $order->client['id'] == $client['id'] ) ? 'selected' : ''); ?>><?php echo e($client['name']); ?></option>
                                    <?php endforeach; ?>  
                                </select>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-8 col-md-offset-2 input-group<?php echo e($errors->has('entry_date') ? ' has-error' : ''); ?>">
                                <span class="input-group-addon" id="entry-date-addon"><b>Data intrare</b></span>
                                <input id="entry_date" type="date" class="form-control col-md-4" name="entry_date" style="padding-left:10px" value="<?php echo e(date('Y-m-d', strtotime($order['entry_date']))); ?>">
                            </div>
                            <?php if($errors->has('entry_date')): ?>
                                    <span class="col-md-8 col-md-offset-2 input-group help-block" style="color: #a94442">
                                        <strong><?php echo e($errors->first('entry_date')); ?></strong>
                                    </span>
                                <?php endif; ?>
                        </div>
                        <div class="row">
                            <div class="col-md-8 col-md-offset-2 input-group<?php echo e($errors->has('partial_date') ? ' has-error' : ''); ?>">
                                <span class="input-group-addon" id="partial-date-addon"><b>Data livrare</b></span>
                                <input id="partial_date" type="date" class="form-control col-md-4" name="partial_date" style="padding-left:10px" value="<?php echo e(date('Y-m-d', strtotime($order['partial_date']))); ?>">
                            </div>
                            <?php if($errors->has('partial_date')): ?>
                                    <span class="col-md-8 col-md-offset-2 input-group help-block" style="color: #a94442">
                                        <strong><?php echo e($errors->first('partial_date')); ?></strong>
                                    </span>
                            <?php endif; ?>
                        </div>
                        <div class="row">
                            <div class="col-md-8 col-md-offset-2 input-group<?php echo e($errors->has('due_date') ? ' has-error' : ''); ?>">
                                <span class="input-group-addon" id="due-date-addon"><b>Data finalizare</b></span>
                                <input id="due_date" type="date" class="form-control col-md-4" name="due_date" style="padding-left:10px" value="<?php echo e(date('Y-m-d', strtotime($order['due_date']))); ?>">
                            </div>
                            <?php if($errors->has('due_date')): ?>
                                    <span class="col-md-8 col-md-offset-2 input-group help-block" style="color: #a94442">
                                        <strong><?php echo e($errors->first('due_date')); ?></strong>
                                    </span>
                            <?php endif; ?>
                        </div>
                        <div class="row">
                            <div class="col-md-8 col-md-offset-2 input-group">
                                <span class="input-group-addon" id="state-addon"><b>Stare</b></span>
                                <?php 
                                    if ($order['state'] == 0) $state = 'In curs de livrare';
                                    else if ($order['state'] == 1) $state = 'Partial livrata';
                                    else if ($order['state'] == 2) $state = 'Livrata';
                                    else if ($order['state'] == 3) $state = 'Suspendata';
                                 ?>
                                <input type="hidden" value="<?php echo e($order['state']); ?>" name="state" />
                                <input type="text" class="form-control" style="cursor: default" aria-describedby="quantity-addon" readonly value="<?php echo e($state); ?>" style="background-color:white">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-8 col-md-offset-2 input-group">
                                <button type="button" class="btn btn-warning dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="display: inline">
                                    <i class="fa fa-btn fa-refresh"></i> Modificare stare <span class="caret"></span>
                                </button>
                                <ul class="dropdown-menu">
                                    <li><a href="<?php echo e(action('OrderController@updateState', array($order['id'], 0))); ?>">In curs de livrare</a></li>
                                    <li><a href="<?php echo e(action('OrderController@updateState', array($order['id'], 2))); ?>">Livrata</a></li>
                                    <li><a href="<?php echo e(action('OrderController@updateState', array($order['id'], 3))); ?>">Suspendata</a></li>
                                </ul>
                                <button type="submit" class="btn btn-info" style="margin-left:15px;">Actualizare</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <!-- Modal -->
    <!--      <div class="modal fade" id="modal-order-data" role="dialog">-->
    <!--        <div class="modal-dialog">-->
            
              <!-- Modal content-->
    <!--          <form class="modal-content" role="form" method="POST" action="<?php echo e(action('OrderController@updateOrderData', array($order['id']))); ?>">-->
    <!--            <?php echo e(csrf_field()); ?>-->
    <!--            <div class="modal-header">-->
    <!--              <button type="button" class="close" data-dismiss="modal">&times;</button>-->
    <!--              <h4 class="modal-title">Cantitate livrata</h4>-->
    <!--            </div>-->
    <!--            <div class="modal-body">-->
                  <!--<p>Au fost livrate &nbsp;&nbsp;&nbsp; <input type="number" name="delivered"  placeholder="2" min="0" style="width:50px; padding-left:10px;"/> &nbsp;&nbsp;&nbsp; din &nbsp;&nbsp;&nbsp; <input type="number" value="<?php echo e($order['quantity'] - $order['delivered']); ?>" style="width:50px; padding-left:10px;" readonly/> </p>-->
                  <!--<p>Au fost livrate &nbsp;&nbsp;&nbsp; <input type="number" name="parcels" placeholder="2" min="0" style="width:50px; padding-left:10px;"/> &nbsp;&nbsp;&nbsp; colete cu greutatea de &nbsp;&nbsp;&nbsp; <input type="number" name="weight" step="0.01" placeholder="12.3" style="width:67px; padding-left:10px;"/> &nbsp;&nbsp;&nbsp; kilograme. </p>-->
                  
    <!--              <div class="row form-group">-->
    <!--                  <label for="delivered" class="col-md-2 control-label" style="padding-top: 5px;">Livrate</label>-->

    <!--                  <div class="col-md-6">-->
    <!--                      <input id="delivered" type="text" class="form-control" name="delivered" value="<?php echo e($order['delivered']); ?>">-->
    <!--                  </div>-->
    <!--              </div>-->
                  
    <!--              <div class="row form-group">-->
    <!--                  <label for="invoiced" class="col-md-2 control-label" style="padding-top: 5px;">Facturate</label>-->

    <!--                  <div class="col-md-6">-->
    <!--                      <input id="invoiced" type="text" class="form-control" name="invoiced_products" value="<?php echo e($order['invoiced_products']); ?>">-->
    <!--                  </div>-->
    <!--              </div>-->
                  
    <!--              <div class="row form-group">-->
    <!--                  <label for="parcels" class="col-md-2 control-label" style="padding-top: 5px;">Colete</label>-->

    <!--                  <div class="col-md-6">-->
    <!--                      <input id="parcels" type="text" class="form-control" name="parcels" value="<?php echo e($order['parcels']); ?>">-->
    <!--                  </div>-->
    <!--              </div>-->
                  
    <!--              <div class="row form-group">-->
    <!--                  <label for="delivered" class="col-md-2 control-label" style="padding-top: 5px;">Greutate</label>-->

    <!--                  <div class="col-md-6">-->
    <!--                      <input id="weight" type="text" class="form-control" name="weight" value="<?php echo e($order['weight']); ?>">-->
    <!--                  </div>-->
    <!--              </div>-->
    <!--              <div style="clear:both;"></div>-->
    <!--            </div>-->
    <!--            <div class="modal-footer">-->
    <!--                <button type="submit" href="" class="btn btn-primary">Modificare</a>-->
    <!--            </div>-->
    <!--          </form>-->
              
    <!--        </div>-->
    <!--      </div>-->
          
    <!--      <div class="modal fade" id="modal-delivered" role="dialog">-->
    <!--        <div class="modal-dialog">-->
            
              <!-- Modal content-->
    <!--          <form class="modal-content" role="form" method="POST" action="<?php echo e(action('OrderController@updateState', array($order['id'], 2))); ?>">-->
    <!--            <?php echo e(csrf_field()); ?>-->
    <!--            <div class="modal-header">-->
    <!--              <button type="button" class="close" data-dismiss="modal">&times;</button>-->
    <!--              <h4 class="modal-title">Cantitate livrata</h4>-->
    <!--            </div>-->
    <!--            <div class="modal-body">-->
    <!--              <p>Au fost livrate &nbsp;&nbsp;&nbsp; <input type="number" name="parcels" placeholder="2" min="0" style="width:50px; padding-left:10px;"/> &nbsp;&nbsp;&nbsp; colete cu greutatea de &nbsp;&nbsp;&nbsp; <input type="number" name="weight" step="0.01" placeholder="12.3" style="width:67px; padding-left:10px;"/> &nbsp;&nbsp;&nbsp; kilograme. </p>-->
    <!--            </div>-->
    <!--            <div class="modal-footer">-->
    <!--                <button type="submit" href="" class="btn btn-primary">Modificare</a>-->
    <!--            </div>-->
    <!--          </form>-->
              
    <!--        </div>-->
    <!--      </div>-->
    <!--</div>-->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>