<?php

namespace App\Http\Controllers;

use Validator;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

use App\Http\Requests;

use PDF;

class OrderController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }
    
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // HomeController@index
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $clients=\App\Client::all();
        return view('order.create', compact('clients'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $messages = [
            'required' => 'Aceasta informatie este obligatorie.',
        ];
        
        $validator = Validator::make($request->all(), [
            'name' => 'required',
            'article' => 'required',
            'quantity' => 'required',
            'client_id' => 'required',
            'due_date' => 'required'
        ], $messages);
        
        if ($validator->fails()) {
            return back()
                        ->withErrors($validator)
                        ->withInput();
        }
        
        $order = new \App\Order;
        $order->name = $request->get('name');
        $order->article = $request->get('article');
        $order->quantity = $request->get('quantity');
        $order->client_id = $request->get('client_id');
        $order->entry_date = date('Y-m-d H:i:s');
        $order->due_date = $request->get('due_date');
        $order->parcels = 0;
        $order->weight = 0;
        $order->price_article = 0;
        $order->price_total = 0;
        $order->save();
        
        return redirect('facturi')->with('success', 'Factura a fost creata');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $order = \App\Order::find($id);
        $clients=\App\Client::all();
        return view('order.show', compact('order', 'id', 'clients'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {

        $validator = Validator::make($request->all(), [
            'name' => 'required',
            'article' => 'required',
            'quantity' => 'required',
            'due_date' => 'required'
        ]);
        
        if ($validator->fails()) {
            return back()
                        ->withErrors($validator)
                        ->withInput();
        }

        $order = \App\Order::find($id);
        $order->name = $request->get('name');
        $order->article = $request->get('article');
        $order->quantity = $request->get('quantity');
        $order->delivered = $request->get('delivered');
        $order->invoiced_products = $request->get('invoiced_products');
        $order->parcels = $request->get('parcels');
        $order->weight = $request->get('weight');
        $order->state = $request->get('state');
        $order->client_id = $request->get('client_id');
        $order->entry_date = $request->get('entry_date');
        $order->partial_date = $request->get('partial_date');
        $order->due_date = $request->get('due_date');
        $order->save();
        
        return back()->with('success', 'Factura a fost actualizata');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $order = \App\Order::find($id);
        $order->delete();
        return back()->with('success', 'Factura a fost stearsa');
    }
    
    /**
     * Get the client that owns the order.
     */
    public function getClient($id)
    {
        $client = \App\Client::find($id);
        return $client->name;
    }
    
    public function downloadPDF($id){
      $orders = \App\Order::find(json_decode($id));
      $pdf = PDF::loadView('pdf.invoice', compact('orders'));
      return $pdf->download('factura-' . date('Y-m-d H:i:s') . '.pdf');
    }
    
    public function downloadPartialPDF(Request $request, $id){
      $order = \App\Order::find($id);
      $order->invoiced_products = $order->invoiced_products + $request->get('invoiced');
      $order->save();
      $pdf = PDF::loadView('pdf.invoice', compact('order'));
      return $pdf->download('factura-partiala-' . $id . '.pdf');
    }
    
    public function updateState(Request $request, $id, $newState)
    {
        
        $order = \App\Order::find($id);
        $order->state = $newState;
        if($newState == 1) {
            $order->delivered = $order->delivered + $request->get('delivered');
            $order->partial_date = date('Y-m-d H:i:s');   
        }
        $order->parcels = $order->parcels + $request->get('parcels');
        $order->weight = $order->weight + $request->get('weight');
        $order->save();
        return back()->with('success', 'Factura a fost actualizata');
    }
    
    public function search(Request $request)
    {
        $clients=\App\Client::all();
        $searchTerm = $request->input('search');
        $from_date = $request->input('from_date');
        $to_date = $request->input('to_date');
        $selectedClient = $request->input('client');
        
        $orders = \App\Order::where(function($query) use ($searchTerm, $selectedClient, $from_date, $to_date) {
                                    if (!is_null($from_date) && $from_date != '') {
                                        $query->whereDate('entry_date', '>=', $from_date);
                                    }
                                    if (!is_null($to_date) && $to_date != '') {
                                        $query->whereDate('entry_date', '<=', $to_date);
                                    }
                                    if (!is_null($from_date) && !is_null($to_date) && $from_date != '' && $to_date != '') {
                                        $query->whereBetween('entry_date', [$from_date, $to_date]);
                                    }
                                    if (!is_null($selectedClient) && $selectedClient != '') {
                                        $query->where('client_id', $selectedClient);
                                    }
                                    if (!is_null($searchTerm) && $searchTerm != '') {
                                        $query->where(function($query) use ($searchTerm) {
                                            $query->where( 'name', 'LIKE', '%' . $searchTerm . '%' );
                                            $query->orWhere('article', 'LIKE', '%' . $searchTerm . '%' ); 
                                        });
                                    }
                            })//->toSql();
                            ->get();
                            //dd($orders);

        return view('facturi', compact('orders', 'searchTerm', 'from_date', 'to_date', 'clients', 'selectedClient'));

    }
    
    public function updateOrderData(Request $request, $id)
    {
        
        $order = \App\Order::find($id);
        $order->delivered = $order->delivered + $request->get('delivered');
        $order->invoiced_products = $order->invoiced_products + $request->get('invoiced_products');
        $order->parcels = $order->parcels + $request->get('parcels');
        $order->weight = $order->weight + $request->get('weight');
        $order->save();
        return view('order.show', compact('order', 'id'))->with('success', 'Factura a fost actualizata');
    }
    
    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function clientOrders($id)
    {
        $orders = DB::table('orders')
                ->where('client_id', $id)
                ->get();
        
        $clientDb = \App\Client::find($id);
        $client = $clientDb->name;
        return view('order.perclient', compact('orders', 'client'));
    }

}
